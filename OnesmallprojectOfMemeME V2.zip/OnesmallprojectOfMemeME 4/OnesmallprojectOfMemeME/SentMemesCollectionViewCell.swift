//
//  SentMemesCollectionViewCell.swift
//  OnesmallprojectOfMemeME
//
//  Created by Amjad khalid  on 29/11/2018.
//  Copyright © 2018 Amjad khaled. All rights reserved.
//

import UIKit
// MARK: - SentMemesCollectionViewCell: UICollectionViewCell
class SentMemesCollectionViewCell: UICollectionViewCell  {
    
    // outlet
    @IBOutlet weak var memeImage: UIImageView!
}
